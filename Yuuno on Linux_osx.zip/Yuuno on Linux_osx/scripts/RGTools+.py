﻿##############################################################################################################################################
# RGTools+ - Wrapper function for optimizations, 32 bit support (some of which is native), and some updated filters that largely use RGTools 
# 8 - 16 bit integer supported, 32 bit float supported
# float 16, or half float, is not supported, as there dont seem to be any lossless int16 <--> flt16 conversion methods
# 
# Included plugin wrappers
# 
# RemoveGrain
# --speed optimizations for modes 4 and 20 (integer)
# --native support for modes 4, 11/12, 19, 20 (float)
# Repair
# --native 32 bit version of mode 1
# VerticalCleaner
# --native 32 bit support for standard mode
# Cleanse + ForwardCleanse + BackwardCleanse
# --native 32 bit support
# Median
# --radius parameter added (int array)
# --uses CTMP when radius[x] > 1
# 
# Iterative functions
# 
# RemoveGrainM
# --syntax is different, basically the same as AVS RemoveGrain, but mode, modeu and modev can take an int array
# --the last value of any of the modes is duplicated if "i" is longer than the length of the mode
# --that is to say, adding a 0 to the end of an array is the closest thing there is to having different settings of "i" per plane 
# RepairM
# --basically the same as RemoveGrainM, it just uses the previous repaired clip as the repair_clip
# --in practise, this should make it weaker
# 
# Updated functions
# 
# sbr + sbrv + sbrh
# --'r' is now an int array, allowing for separate radius settings for different planes
# --no upper limit for 'r' settings
# MinBlur
# --'r' is now an int array, allowing for separate radius settings for different planes
# --no upper limit for 'r' settings
# ContraSharpening
# --support for different clip formats (i.e. bitdepth) for convenience
##############################################################################################################################################
import vapoursynth as vs
core = vs.core

medexpr = 'x y z min max y z max min'


def Repair(clip, repair_clip, mode=2):

    def rep1(clip, repair_clip, planes):
        if len(planes)==0:
            return clip
        rmax = repair_clip.std.Maximum(planes=planes)
        rmin = repair_clip.std.Minimum(planes=planes)
        mexpr = []
        for i in range(clip.format.num_planes):
            mexpr += ['x y min z max' if i in planes else '']
        return core.std.Expr([clip, rmax, rmin], mexpr)
        
    if any_of([clip, repair_clip], 'not isinstance', vs.VideoNode):
        raise TypeError('Repair: This is not a clip')
    
    f = clip.format
    cf = f.color_family
    bits = f.bits_per_sample
    isfloat = f.sample_type==vs.FLOAT
    numplanes = f.num_planes
    full = f.color_family in (vs.RGB, vs.YCOCG)
    
    rf = repair_clip.format
    rnumplanes = rf.num_planes
    
    mode = append_params(mode, 'copy', numplanes)
    
    if numplanes > rnumplanes:
        del mode[rnumplanes:]
        for i in range(numplanes-rnumplanes):
            mode += [0]
    
    if f!=rf:
        rc_fmt = core.register_format(cf, vs.FLOAT if isfloat else vs.INTEGER, bits, f.subsampling_w, f.subsampling_h)
        repair_clip = repair_clip.resize.Bicubic(filter_param_a=0, filter_param_b=0.5, format=rc_fmt.id, dither_type='none')
        
    if not isfloat:
        return clip.rgvs.Repair(repair_clip, mode)
    
    planes_mode1 = []
    planes_flt = []
    for i in range(numplanes):
        if mode[i] in (1, 11):
            mode[i] = 0
            planes_mode1 = planes_mode1 + [i]
        if mode[i] not in (0, 1, 11):
            planes_flt = planes_flt + [i]
        
    mexpr = []
    while len(mexpr) < numplanes:
        mexpr.append('' if len(mexpr) not in planes_flt else 'x y - abs {} < x y ?'.format(.5/65535 if full else .5/56064 if len(mexpr)==0 else .5/57344))
        
    clip = rep1(clip, repair_clip, planes_mode1)
        
    if not any_of(mode, 'not in', (0, 1, 11)):
        return clip
        
    clip16 = Depth(clip, 16, planes_flt)
    repair_clip16 = Depth(repair_clip, 16, planes_flt)
    out = clip16.rgvs.Repair(repair_clip16, mode)
    out = Depth(out, 32, planes_flt)
        
    return clip.text.Text(str(mode[0])+' '+str(mode[1])) #core.std.Expr([clip, out], mexpr)

def RemoveGrain(clip, mode=2):
    def rg4(clip, planes):
        if len(planes)==0:
            return clip
        return clip.std.Median(planes=planes)
    def rg11(clip, planes):
        if len(planes)==0:
            return clip
        return clip.std.Convolution([1,2,1,2,4,2,1,2,1], planes=planes)
    def rg19(clip, planes):
        if len(planes)==0:
            return clip
        return clip.std.Convolution([1,1,1,1,0,1,1,1,1], planes=planes)
    def rg20(clip, planes):
        if len(planes)==0:
            return clip
        return clip.std.Convolution([1]*9, planes=planes)
        
    if not isinstance(clip, vs.VideoNode):
        raise TypeError('RemoveGrain: This is not a clip')
        
    f = clip.format
    bits = f.bits_per_sample
    isfloat = f.sample_type==vs.FLOAT
    numplanes = f.num_planes
    full = f.color_family in (vs.RGB, vs.YCOCG) or (bits==16 and isfloat)
    
    mode = append_params(mode, 'copy', numplanes)
    
    mode_int = append_params([], 0, numplanes)
    mode_flt = append_params([], 0, numplanes)
    planes_med = []
    planes_gauss = []
    planes_navg = []
    planes_avg = []
    planes_flt = []
    
    for i in range(numplanes):
        if mode[i]==4:
            planes_med += [i]
        elif mode[i]==20:
            planes_avg += [i]
        else:
            mode_int[i] = mode[i]
    
    clip = rg4(clip, planes_med)
    clip = rg20(clip, planes_avg)
    
    if bits<32:
        return clip.rgvs.RemoveGrain(mode_int)
    
    for i in range(numplanes):
        if mode[i] in (11,12):
            planes_gauss = planes_gauss + [i]
        if mode[i]==19:
            planes_navg = planes_navg + [i]
        if mode[i] not in (0,4,11,12,19,20):
            planes_flt += [i]
            mode_flt[i] = mode[i]
            
    mexpr = []
    while len(mexpr) < numplanes:
        mexpr.append('' if len(mexpr) not in planes_flt else 'x y - abs {} < x y ?'.format(.5/65535 if full else .5/56064 if len(mexpr)==0 else .5/57344))
        
    clip = rg11(clip, planes_gauss)
    clip = rg19(clip, planes_navg)
        
    if not any_of(mode, 'not in', (0,4,11,12,19,20)):
        return clip
    
    clip_16 = Depth(clip, 16, planes_flt)
    rg_16 = clip_16.rgvs.RemoveGrain(mode_flt)
    out = Depth(rg_16, 32, planes_flt)

    return core.std.Expr([clip, out], mexpr)

def RepairM(clip, repair_clip, mode=2, modeu=None, modev=None, i=None):
    if any_of([clip, repair_clip], 'not isinstance', vs.VideoNode):
        raise TypeError('RepairM: This is not a clip')
    if i is None:
        tmp_m = [mode] if not isinstance(mode, list) else mode
        tmp_mu = [modeu] if not isinstance(modeu, list) else modeu
        tmp_mv = [modev] if not isinstance(modev, list) else modev
        i = max(len(tmp_m), len(tmp_mu), len(tmp_mv))
        
    mode = append_params(mode, 'copy', length=i)
    modeu = mode if modeu is None else append_params(modeu, 'copy', length=i)
    modev = modeu if modev is None else append_params(modev, 'copy', length=i)
    
    while max(mode[i-1], modeu[i-1], modev[i-1])<=0:
        i -= 1
    for n in range(i):
        repair_clip = Repair(clip, repair_clip, [mode[n],modeu[n],modev[n]])
    
    return repair_clip

def RemoveGrainM(clip, mode=2, modeu=None, modev=None, i=None):
    if not isinstance(clip, vs.VideoNode):
        raise TypeError('RemoveGrainM: This is not a clip')
    if i is None:
        tmp_m = [mode] if not isinstance(mode, list) else mode
        tmp_mu = [modeu] if not isinstance(modeu, list) else modeu
        tmp_mv = [modev] if not isinstance(modev, list) else modev
        i = max(len(tmp_m), len(tmp_mu), len(tmp_mv))
        
    mode = append_params(mode, 'copy', length=i)
    modeu = mode if modeu is None else append_params(modeu, 'copy', length=i)
    modev = modeu if modev is None else append_params(modev, 'copy', length=i)
    
    while max(mode[i-1], modeu[i-1], modev[i-1])<=0:
        i -= 1
    
    for n in range(i):
        clip = RemoveGrain(clip, [mode[n],modeu[n],modev[n]])
    return clip

# aliases for removegrain and repair
removegrain = RemoveGrain
rg = RemoveGrain

removegrainm = RemoveGrainM
rgm = RemoveGrainM

repair = Repair
rep = Repair

repairm = RepairM
repm = RepairM

def sbr(clip, r=1, planes=None):
    if not isinstance(clip, vs.VideoNode):
        raise TypeError('sbr: This is not a clip')
    return sbr_internal(clip, r, planes, True, True)
def sbrh(clip, r=1, planes=None):
    if not isinstance(clip, vs.VideoNode):
        raise TypeError('sbrh: This is not a clip')
    return sbr_internal(clip, r, planes, True, False)
def sbrv(clip, r=1, planes=None):
    if not isinstance(clip, vs.VideoNode):
        raise TypeError('sbrv: This is not a clip')
    return sbr_internal(clip, r, planes, False, True)

def sbr_internal(clp, r=1, planes=None, h=True, v=True):

    def blurhv(clp, radius, mode, planes):
        numplanes = len(radius)
    
        # Gaussian blur stage
        clp = clp.std.Convolution([1,2,1], planes=planes, mode=mode)
        
        for i in range(numplanes):
            radius[i] = radius[i] - 1
            
        if max(r)==0:
            return clp
        
        # Average blur stage
        for i in range(max(radius)):
            # remove radii that have reached zero
            for n in range(numplanes):
                if n in planes and radius[n]==0:
                    planes = planes.remove(n)
            # blur
            clp = clp.std.Convolution([1,1,1], planes=planes, mode=mode)
            # radii - 1
            for n in range(numplanes):
                radius[n] = radius[n] - 1
        return clp
    
    f = clp.format
    bits = f.bits_per_sample
    isfloat = f.sample_type==vs.FLOAT
    numplanes = f.num_planes
    
    planes = list(range(numplanes)) if planes is None else [planes] if isinstance(planes, int) else planes
    
    r = append_params(r, 'copy', numplanes)
    if len(r) > numplanes:
        del r[numplanes:len(r)-1]
    
    for i in range(numplanes):
        if i not in planes:
            r[i] = 0
        elif r[i]==0:
            planes = planes.remove(i)
            
    if max(r)<1:
        return clp
    
    hvmode = 'v' if not h else 'h' if not v else 's'
    
    expr = 'x y - x {neutral} - * 0 < {neutral} x y - abs x {neutral} - abs < x y - {neutral} + x ? ?'.format(neutral=1 << (bits - 1))
    expr = 'x y - x * 0 < 0 x y - abs x abs < x y - x ? ?' if isfloat else expr
    
    mexpr = []
    mode = [[]] * numplanes
    
    for i in range(numplanes):
        mexpr += [expr if i in planes else '']
        if i in planes:
            while len(mode[i]) < ( r[i] + 1 ):
                mode[i].append(0 if len(mode[i])==r[i] else 20 if len(mode[i])>0 else 11)
        else: 
            mode[i] = 0
    
    RG11 = RemoveGrainM(clp, mode[0], mode[1], mode[2], max(r)) if hvmode=='s' else blurhv(clp, r, hvmode, planes)
    
    RG11D = core.std.MakeDiff(clp, RG11, planes=planes)
    
    RG11DS = RemoveGrainM(RG11D, mode[0], mode[1], mode[2], max(r)) if hvmode=='s' else blurhv(clp, r, hvmode, planes)
    
    RG11DD = core.std.Expr([RG11D, RG11DS], mexpr)
    
    return core.std.MakeDiff(clp, RG11DD, planes=planes)


def MinBlur(clp, r=1, planes=None):
    
    if not isinstance(clp, vs.VideoNode):
        raise TypeError('MinBlur: This is not a clip')
    
    f = clp.format
    bits = f.bits_per_sample
    isfloat = f.sample_type==vs.FLOAT
    numplanes = f.num_planes
    
    planes = list(range(numplanes)) if planes is None else [planes] if isinstance(planes, int) else planes
    
    r = append_params(r, 'copy', numplanes)
    if len(r) > numplanes:
        del r[numplanes:len(r)-1]
    
    for i in range(numplanes):
        r[i] = clamp(r[i], -1, 127)
        if i not in planes:
            r[i]==-1
        elif r[i]<0:
            planes = planes.remove(i)
    
    mexpr = []
    sbr_planes = []
    mode = [[]] * numplanes
    
    expr = 'x {neutral} - y {neutral} - * 0 < {neutral} x {neutral} - abs y {neutral} - abs < x y ? ?'.format(neutral=1 << (bits - 1))
    expr = 'x y * 0 < 0 x abs y abs < x y ? ?' if isfloat else expr
    
    for i in range(numplanes):
        mexpr += [expr if i in planes else '']
        if i in planes:
            if r[i]==0:
                sbr_planes += [i]
                mode[i] = 0
            else:
                while len(mode[i]) < ( r[i] + 1 ):
                    mode[i].append(0 if len(mode[i])==r[i] else 20 if len(mode[i])>0 else 11)
            mode[i] += [0]
        else:
            mode[i] = 0
            
    RG11 = sbr(clp, r=1, planes=sbr_planes) if 0 in r else clp
    RG11 = RemoveGrainM(RG11, mode[0], mode[1], mode[2], i=max(r)) if max(r)>0 else RG11
    RG4 = Median(clp, r, planes)
    
    RG11D = core.std.MakeDiff(clp, RG11, planes=planes)
    RG4D = core.std.MakeDiff(clp, RG4, planes=planes)
    DD = core.std.Expr([RG11D, RG4D], mexpr)
    
    return core.std.MakeDiff(clp, DD, planes=planes)

def clense_flt(clip, ref, ref2, mode, planes):

    numplanes = clip.format.num_planes
    last_frame = clip.num_frames - 1
        
    planes = list(range(numplanes)) if planes is None else [planes] if isinstance(planes, int) else planes
    
    mexpr = []
    for i in range(numplanes):
        mexpr += [medexpr if i in planes else '']
    
    if mode=='fwd':
        ref = clip.std.DuplicateFrames(last_frame).std.DeleteFrames(0)
        ref2 = ref.std.DuplicateFrames(last_frame).std.DeleteFrames(0)
    elif mode=='back':
        ref = clip.std.DeleteFrames(last_frame).std.DuplicateFrames(0)
        ref2 = ref.std.DeleteFrames(last_frame).std.DuplicateFrames(0)
    else:
        if ref is None:
            ref = clip.std.DuplicateFrames(last_frame).std.DeleteFrames(0)
        if ref2 is None:
            ref2 = clip.std.DeleteFrames(last_frame).std.DuplicateFrames(0)
                
    return core.std.Expr([clip, ref, ref2], mexpr)

def Clense(clip, forward=None, backward=None, planes=None):
    if not isinstance(clip, vs.VideoNode):
        raise TypeError('Clense: This is not a clip')
    if not isinstance(forward, vs.VideoNode):
        forward = None
    if not isinstance(backward, vs.VideoNode):
        backward = None
    if clip.format.sample_type==vs.INTEGER:
        return core.rgvs.Clense(clip, forward, backward, planes)
    return clense_flt(clip, forward, backward, 'std', planes)

def ForwardClense(clip, planes=None):
    if not isinstance(clip, vs.VideoNode):
        raise TypeError('ForwardClense: This is not a clip')
    if clip.format.sample_type==vs.INTEGER:
        return core.rgvs.ForwardCleanse(clip, planes)
    return clense_flt(clip, None, None, 'fwd', planes)

def BackwardClense(clip, planes=None):
    if not isinstance(clip, vs.VideoNode):
        raise TypeError('BackwardClense: This is not a clip')
    if clip.format.sample_type==vs.INTEGER:
        return core.rgvs.BackwardClense(clip, planes)
    return clense_flt(clip, None, None, 'back', planes)
    

def VerticalCleaner(clip, mode=1):

    def vc_flt(clip, mode):
    
        f = clip.format
        bits = f.bits_per_sample
        full = f.color_family in (vs.RGB, vs.YCOCG)
        numplanes = f.num_planes
        
        mode = append_params(mode, 'copy', numplanes)
        
        imode = []
        dexpr = []
        mexpr = []
        dplns = []
        fplns = []
        
        for i in range(numplanes):
            imode += [0 if mode[i]!=2 else 2]
            dexpr += ['' if mode[i]!=2 else 'y' if bits==16 else 'x y - abs {} <  x y ?'.format(.5/65535 if full else .5/56064 if i==0 else .5/57344)]
            mexpr += ['' if mode[i]!=1 else medexpr]
            fplns += [1 if mode[i]!=1 else 3]
            if mode[i]==2:
                dplns += [i]
        
        if 1 in mode:
            ref1 = core.fmtc.resample(clip, sh=[1]*numplanes, planes=fplns) if numplanes > 1 else core.resize.Point(clip, src_top=1)
            ref2 = core.fmtc.resample(clip, sh=[-1]*numplanes, planes=fplns) if numplanes > 1 else core.resize.Point(clip, src_top=-1)
            clip = core.std.Expr([clip, ref1, ref2], mexpr)
            
        if 2 in mode:
            vc16 = Depth(clip, 16, dplns).rgvs.VerticalCleaner(mode=imode)
            out = Depth(vc16, 32, dplns)
            clip = core.std.Expr([clip, out], dexpr)
            
        return clip
    
    if clip.format.sample_type==vs.FLOAT:
        return vc_flt(clip, mode)
    else:
        return core.rgvs.VerticalCleaner(clip, mode)

def Median(clip, r=1, planes=None):
    
    f = clip.format
    st = f.sample_type
    full = f.color_family in (vs.RGB, vs.YCOCG)
    numplanes = f.num_planes
    
    planes = list(range(numplanes)) if planes is None else [planes] if isinstance(planes, int) else planes
    
    radius = append_params(r, 'copy', numplanes)
    for i in range(numplanes):
        radius[i] = 0 if i not in planes else clamp(radius[i], 0, 127)
    
    if max(radius)<=0:
        return clip
        
    for i in range(numplanes):
        if i in planes and radius[i]==0:
            planes = planes.remove(i)
        
    while 0 in radius:
        radius.remove(0)
        
    if 1 in radius:
        mplanes = []
        for i in range(len(radius)):
            if radius[i]==1:
                mplanes += [planes[i]]
        clip = clip.std.Median(planes=mplanes)
        if max(radius)==1:
            return clip
        
    while 1 in radius:
        del planes[radius.index(1)]
        radius.remove(1)
        
    mexpr = []
    while len(mexpr) < numplanes:
        mexpr.append('' if len(mexpr) not in planes else 'x y - abs {} <  x y ?'.format(.5/65535 if full else .5/56064 if len(mexpr)==1 else .5/57344))
        
    clip16 = Depth(clip, 16, planes) if st==vs.FLOAT else clip
        
    if len(radius)==1 or max(radius)==min(radius):
        clip16 = clip16.ctmf.CTMF(radius=radius[0], planes=planes)
    elif len(radius)==2:
        for i in range(2):
            clip16 = clip16.ctmf.CTMF(radius=radius[i], planes=planes[i])
    elif len(radius)==3:
        if radius[0]==radius[1]:
            clip16 = clip16.ctmf.CTMF(radius=radius[0], planes=[0,1]).ctmf.CTMF(radius=radius[2], planes=[2])
        elif radius[1]==radius[2]:
            clip16 = clip16.ctmf.CTMF(radius=radius[1], planes=[1,2]).ctmf.CTMF(radius=radius[0], planes=[0])
        elif radius[0]==radius[2]:
            clip16 = clip16.ctmf.CTMF(radius=radius[0], planes=[0,2]).ctmf.CTMF(radius=radius[1], planes=[1])
        else:
            for i in range(3):
                clip16 = clip16.ctmf.CTMF(radius=radius[i], planes=planes[i])
    
    if st==vs.INTEGER:
        return clip16
        
    out = Depth(clip16, 32, planes)
    clips = [clip, out]
    return core.std.Expr(clips, mexpr)

# TODO: Dumb matrix shit for mixed YUV/GRAY and YCOCG/RGB
#def contrasharp(denoised, original, radius=1, rep=1):
#    df = denoised.format
#    dcf = df.color_family
#    dbits = df.bits_per_sample
#    dst = df.bits_per_sample
#    dfmt_gray = core.register_format(vs.GRAY, dst, dbits, 0, 0)
#    dfmt_ycocg = core.register_format(vs.YCOCG, dst, dbits, 0, 0)
#    dfmt_rgb = core.register_format(vs.RGB, dst, dbits, 0, 0)
#    
#    iw = denoised.width
#    ih = denoised.height
#    guess_mtx = 5 if iw <= 1024 and ih <= 576 else 1 if iw <= 2048 and ih <= 1536 else 9
#    
#    of = original.format
#    ocf = of.color_family
#    obits = of.bits_per_sample
#    ost = of.bits_per_sample
#    omtx = 8 if not any_of([dcf, ocf] 'not in' (vs.YCOCG, vs.RGB)) else guess_mtx if ocf in (vs.YCOCG, vs.RGB) and dcf in (vs.YUV, vs.GRAY) else None
#    orange = 1 if dcf in (vs.YCOCG, vs.RGB) else 0
#    ofmt = core.register_format(vs.GRAY, dst, dbits, 0, 0)
#    oconv = ocf==vs.RGB or (dbits, dst)!=(obits, ost) or 
#    
#    denoised_src = denoised.resize.Point(format=dfmt_ycocg.id, matrix=8, range=1) if dcf==vs.RGB else denoised if cf != vs.GRAY else None
#    denoised = denoised.resize.Point(format=dfmt_gray.id, matrix=8, range=1) if dcf==vs.RGB else core.std.ShufflePlanes(denoised, 0, vs.GRAY) if dcf!=vs.GRAY else denoised
#    original = original.resize.Point(format=ofmt.id, matrix=omtx, range=orange) if oconv else core.std.ShufflePlanes(original, 0, vs.GRAY) if ocf!=vs.GRAY else original
#    
#    radius = clamp(radius)
#    
#    s = rgtools.MinBlur(denoised, 1)
#    
#    RG11 = rgtools.RemoveGrain(s, 11)
#    
#    if radius > 1:
#        RG11 = rgtools.RemoveGrainM(RG11, [20]*min(2, radius-1))
#    
#    ssD = core.std.MakeDiff(s, RG11)             # The difference of a simple kernel blur.
#    allD = core.std.MakeDiff(original, denoised) # The difference achieved by the denoising.
#    if rep not in (0, 1, 11) and bits==32:
#        ssD16 = core.std.Expr(allD16, 'x 0.5 +').resize.Point(format=vs.GRAY16, range_in=1, range=1, dither_type='none')
#        allD16 = core.std.Expr(allD16, 'x 0.5 +').resize.Point(format=vs.GRAY16, range_in=1, range=1, dither_type='none')
#        
#        ssDD = Repair(ssD16, allD16, [rep], radius)
#        ssDD = ssDD.resize.Point(format=vs.GRAYS, range_in=1, range=1).std.Expr('x 0.5 -')
#        ssDD = core.std.Expr([ssD, ssDD], 'x abs 0.5 > y abs {} >= and x y - abs {} <= or x y ?'.format(0.5 - (1/131070), 1/131070) )
#        #ssDD = core.std.Expr([ssD, ssDD], 'x abs 0.5 > y abs {} >= and x x y - abs {} < x y ? ?'.format(0.5 - (1/131070), 1/131070) )
#    else:
#        ssDD = rgtools.RepairM(ssD, allD, [rep], radius)
#    
#    
#    
#    expr = 'x {neutral} - abs y {neutral} - abs < x y ?'.format(neutral=1 << (denoised.format.bits_per_sample - 1)) if bits<32 else 'x abs y abs < x y ?'
#    ssDD = core.std.Expr([ssDD, ssD], [expr])    # abs(diff) after limiting may not be bigger than before.
#    last = core.std.MergeDiff(denoised, ssDD)    # Apply the limited difference. (Sharpening is just inverse blurring.)
#    
#    if denoised_src is not None:
#        if dcf==vs.YUV:
#            return core.std.ShufflePlanes([last, denoised_src], planes=[0, 1, 2], colorfamily=cf)
#        else:
#            merged = core.std.ShufflePlanes([last, denoised_src], planes=[0, 1, 2], colorfamily=vs.YCOCG)
#            return merged if dcf==vs.YCOCG else merged.resize.Point(format=dfmt_rgb.id)
#    else:
#        return last
    
def Depth(clip, bits, planes):
    f = clip.format
    
    if len(planes)<f.num_planes:
        return clip.fmtc.bitdepth(bits=bits, planes=planes, dmode=1)
    else:
        fmt = core.register_format(f.color_family, vs.FLOAT if bits==32 else vs.INTEGER, bits, f.subsampling_w, f.subsampling_h)
        return core.resize.Spline36(clip, format=fmt.id, dither_type='none')
    
def append_params(params, mode='copy', length=3):
    if not isinstance(params, list):
        params=[params]
    if isinstance(mode, list):
        while len(params)<length:
            params.append(None)
        for i in range(min(length, len(mode))):
            params[i] = mode[i] if params[i] is None else params[i]
    if not isinstance(mode, str) or mode not in ('none', 'null', 'copy', 'half', 'double'):
        while len(params)<length:
            params.append(mode)
        return params
    mode = mode.lower()
    if mode in ('none', 'null'):
        while len(params)<length:
            params.append(None)
    if mode=='copy':
        while len(params)<length:
            params.append(0 if len(params)==0 else params[len(params)-1])
    if mode=='half':
        while len(params)<length:
            params.append(0 if len(params)==0 else params[len(params)-1]/2)
    if mode=='double':
        while len(params)<length:
            params.append(0 if len(params)==0 else params[len(params)-1]*2)
    return params
    
def any_of(arr, mode, val):
    if mode=='<':
        for obj in arr:
            if obj<val:
                return True
        return False
    elif mode=='<=':
        for obj in arr:
            if obj<=val:
                return True
        return False
    elif mode=='>':
        for obj in arr:
            if obj>val:
                return True
        return False
    elif mode=='>=':
        for obj in arr:
            if obj>=val:
                return True
        return False
    elif mode=='==':
        for obj in arr:
            if obj==val:
                return True
        return False
    elif mode=='!=':
        for obj in arr:
            if obj!=val:
                return True
        return False
    elif mode=='in':
        for obj in arr:
            if obj in val:
                return True
        return False
    elif mode=='not in':
        for obj in arr:
            if obj not in val:
                return True
        return False
    elif mode=='is':
        for obj in arr:
            if obj is val:
                return True
        return False
    elif mode=='isinstance':
        for obj in arr:
            if isinstance(obj, val):
                return True
        return False
    elif mode=='not isinstance':
        for obj in arr:
            if not isinstance(obj, val):
                return True
        return False
    else:
        raise ValueError('any_of: invalid mode setting')
        
def clamp(val, minval=1, maxval=3):
    return min(maxval, max(minval, val))
        
sbr(core.std.BlankClip(format=vs.YUV444PS), r=[1,2], planes=[0,1]).set_output()