def znedi3_rpow2(clip,rfactor,correct_shift="zimg",nsize=0,nns=3,qual=None,etype=None,pscrn=None,opt=None,int16_prescreener=None,int16_predictor=None,exp=None):
	from vapoursynth import core
	import edi_rpow2
	
	def edi(clip,field,dh):
		return core.znedi3.nnedi3(clip=clip,field=field,dh=dh,nsize=nsize,nns=nns,qual=qual,etype=etype,pscrn=pscrn,opt=opt,int16_prescreener=int16_prescreener,int16_predictor=int16_predictor,exp=exp)
	
	return edi_rpow2.edi_rpow2(clip=clip,rfactor=rfactor,correct_shift=correct_shift,edi=edi)

