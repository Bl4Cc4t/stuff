import vapoursynth as vs
from vapoursynth import core
import functools as functools

def atxcr_merge(censored, uncensored, thr=2.0):
    def chroma_u_diff(n, f, thr, clip):
        if f.props.PlaneStatsDiff > thr:
            return core.text.Text(clip, "This clip is censored.")
        return core.text.Text(clip, "This clip is uncensored.")
        
    censored_chroma_u = core.std.ShufflePlanes(censored, 1, vs.GRAY)    
    uncensored_chroma_u = core.std.ShufflePlanes(uncensored, 1, vs.GRAY)
    diff = core.std.PlaneStats(censored_chroma_u, uncensored_chroma_u)
    diff = core.std.FrameEval(censored, functools.partial(chroma_u_diff, thr=thr, clip=censored), prop_src=diff)
    return diff