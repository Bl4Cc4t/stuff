﻿import vapoursynth as vs

def flag(clip): return clip.yadifmod.Yadifmod(clip.znedi3.nnedi3(3), 1, mode=1)